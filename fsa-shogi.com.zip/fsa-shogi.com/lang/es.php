<?php

$lang = array(
	
	"menu_home" => "Inicio",
	"menu_news" => "Noticias",
	"menu_ranking" => "Ranking",
	"menu_gallery" => "Galeria",
	"menu_tournaments" => "Torneos",
	"menu_ours" => "Nosotros",
	"menu_links" => "Links",
	"menu_languaje" => "Language",
	"menu_contact" => "Cantáctanos",
	"menu_send" => "Enviar",

	"main-title-1" => "Federación de Shogi",
	"main-title-2" => "Americana",
	

	//Tournament//
	"Tournament" => "Tournament",
	"T-months" => "¡Forma parte de los Torneos mensuales!",
	"join-discord" => "Unéte a nuestro Discord",
	"T-july" => "Torneo de Julio",
	"Format" => "Formato",
	"t-july-2" => "Torneo de Julio de la FSA 2020",
	"direct-removal" => "Eliminación directa",
	"Period" => "Periodo",
	"Status" => "Estatus",
	"Click-see" => "Click para cer en 81dojo.com",

	"japan" => "Japan",
	"japanese-culture" => "Más sobre la cultura japones y el Shogi",
	"meetings" => "Reuniones samanales por Discord",
	"saturday" => "Sábado a las 19 horas UTC-4",
	"culture" => "Cultura",
	"article" => "Artículos",
	"proverb-1" => "Aprendes un poco de la victoria, pero aprendes mucho más de la derrota. Proverbio Japones",
	"proverb-2" => "Todos los hombres pueden ver estas tácticas por las que se conquista, pero lo que nadie puede ver es la estrategia a partir de la cual se desarrolla la victoria. Sun Tzu.",

	//News//
	"books" => "Algunos libros de Shogi recomendados",
	"books-2" => "Hay numerosos libros de Shogi escritos y de gran calidad. Podemos mencionar algunos:'Breve Introcucción al Shogi' de Roger Hare,
'Shogi Handicap Openings' de Shogi magazine, 'Introduction to Handicap Play' de Larry Kaufman, 'Better Moves for Better Shogi' de
Aono Teruichi, 'The Art of Shogi' de Tony Hosking",
	"strategy" => "Estrategias",
	"agost" => "Agosto",
	"deepmind" => "Google DeepMind y el Shogi",
	"deepmind-1" => "Increible cómo Google Deep Mind logró crear una inteliengia Artificial de tal forma que le ganará a Elmo, el hasta entonces Campeón Mundial de Shogi.",
	"deepmind-2" => "AlphaZero es un programa computacional que desarrollo Google a través de un equipo multidiciplinario.
Hay varias versiones del AlphaZero pero una de las versiones más recientes permite aprender Shogi, Ajedrez y Go
desde cero, es decir, sólo con las reglas del juego AlphaZero aprende a jugar, crea su propia teoría de juego
y en contrastes con otros softwares no necesita base de datos de aperturas ni nada parecido. Esto lo permite un conjunto
de tecnicas, algoritmos denominados Reinforcement Learnind, Redes Neuronales Convolucionales, algoritmo de MonteCarlo etc.

AlphaZero en el caso de Shogi y sus partidas contra el mejor programa del mundo , estuvo con un procentaje mayor de victoria. Es decir, AlphaZero
logra tener una estrategia de juego superior a cualquier otro programa antes hecho para el Shogi. El mismo resultado lo obtuvo al jugar Go y Ajedrez
con los mejores programas respectivos en cada disciplina.

La Inteligencia Artificial y todos estos avances contribuyen ha que el jugador que está en constante formación y avance logre aprender usando a estos
como programas como apoyo a traves de revisiones de partidas jugadas.",
	"technology" => "Tecnología",
	"shogi-opening" => "Aperturas en el Shogi",
	"shogi-opening-2" => "Descubre algunas variantes en varias aperturas en el Shogi",
	"shogi-opening-3" => "Las apareturas son muy importantes en el Shogi. En la paretura de Torre Estatica, tenemos
el Side Pawn, Yagura, Bishop Exchange, Double Wing y en la Ranging Rook se tiene 
la Central, Fourth, Tercera y la opuesta. Conocer las variantes en cada una de estas aperturas
ayudará a que el jugador en formación logre subir de nivel en su juego. Tambien el conocer
los distintos Castillos y como atacarlos es algo vital en el Shogi. 

Una de las páginas webs que tiene material al respecto es la Página Web de la Asociación de Shogi
de Bélgica.",
	"opening" => "Apertura",
	"shogi-and-go" => "El Shogi y el Go",
	"shogi-and-go-2" => "Hay varias cosas en comunes entre estos dos juegos de estrategias. uno es que en ambas disciplinas es fundamental el sente, también tiene estudios en cuanto a aperturas, finales. A parte de esto podemos decir que los jugadores se clasifican entre niveles de fuerza usando el sistema kyu-Dan usado también para las Artes Marciales. Los jugadores más fuertes se forman con mucha disciplina, estudio y alto nivel de concentración cuando están en una partida. En cuanto a los programas computacionales en el Shogi tenemos: Elmo, Hefeweizen, Ponanza entre otros. En el Go se tiene: KataGo, Leela entre otros programas. Sin duda alguna, estos Deportes-Ciencias desarrolla en cada uno de los practicantes una nueva forma de ver al mundo y desarrolla habilidades como la concentración, la memoria, la resolución de problemas, la disciplina, el respeto por el oponente y la integración cultural.",
	"animes" => "Animes",
	"art-ia" => "Algunos avances que ha alcanzado la Inteligencia Artificial",
	"art-ia-1" => "¿De que forma a influenciado el desarrollo de Inteliegncias Artificiales en el Shogi, Go-Baduk, Ajedrez en el ambito de la Inteligencia Artificial?.
Despues de que Deepl Blue le ganara a Kaparov a finales de la decadas de los 90,
los programas de ajedrez apoyaron de forma muy sustancial y siguen apoyando en la formación del aejdrecista desde el mejor del mundo, Gran Maestro Magnus Carlsen 
como de los jugadores de clubes. Esto mismo sucede en el Go, en donde las inteligencias Artficiales que fueron sofisticadas desde el 2016 para acá
con los avances tecnologicos de DeepMind, los programas en el Go se han vuelto muy fuertes, tanto asi que a los jugadores profesionales del Go
les logran ganar a las maquinas pero con al menos dos piezas de handicap. Los programas de Go como Leela, KataGo se han vuelto muy utiles y hoy ayuda a miles de jugadores 
en el mundo para mejorar cada vez mas su tecnica en la disciplina. En el Shogi de forma similar los programas ayudan a mejorar el nivel de jeugo en éste Deporte Ciencia. A
traves de revisiones de partidas, los programas ayudan a conseguir la jugada más eficaz en una posición dada. Además pueden dar un balance en el juego de tal forma que 
nos haga saber quien puede tener una ventaja con respecto al otro jugador en un determinado momento del juego.",
	"instagram" => "Instagram feed ",


	///Ours FSA///
	"main-title-ours" => "Federación Americana de Shogi",
	"mision-fsa" => "La Federación de Shogi Americana tiene como misión la integración de los jugadores de Shogi y sus respectivas Asociaciones Nacionales.",
	"fsa-members" => "Actualmente cuenta con representantes de:",
	"argentina" => "Argentina",
	"brasil" => "Brasil",
	"canada" => "Canadá",
	"chile" => "Chile",
	"colombia" => "Colombia",
	"cuba" => "Cuba",
	"usa" => "Estados Unidos de América",
	"guatemala" => "Guatemala",
	"honduras" => "Honduras",
	"mexico" => "México",
	"peru" => "Perú",
	"republica-dominicana" => "República Dominicana",
	"venezuela" => "Venezuela",
	"culture-japanese" => "Más sobre la cultura japonesa y el Shogi",
	"proverb-about" => "Se aprende un poco de la victoria, se aprende mucho de una derrota",
	"japanese-proverb" => "Proverbio japonés",
	




);


