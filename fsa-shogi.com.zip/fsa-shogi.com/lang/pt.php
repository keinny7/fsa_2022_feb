<?php

$lang = array(
	
	"menu_home" => "Home",
	"menu_news" => "Notícias",
	"menu_ranking" => "Ranking",
	"menu_gallery" => "Galeria",
	"menu_tournaments" => "Torneio",
	"menu_ours" => "Nós",
	"menu_links" => "Links",
	"menu_languaje" => "Língua",
	"menu_contact" => "Contacto",
	"menu_send" => "Enviar",

	"main-title-1" => "Federação Americana",
	"main-title-2" => "de Shogi",

	//Tournament//
	"Tournament" => "Torneio",
	"T-months" => "Participe no nosso Torneio Shogi mensal!",
	"join-discord" => "Junte-se a nós na Discord",
	"T-july" => "Torneio de julho",
	"Format" => "Formato",
	"t-july-2" => "Torneio FSA de Julho 2020",
	"direct-removal" => "Remoção directa",
	"Period" => "Período",
	"Status" => "Satuts",
	"Click-see" => "Clique para ver no 81dojo.com",

	"japan" => "Japão",
	"japanese-culture" => "Mais sobre a cultura japonesa e Shogi",
	"meetings" => "Reuniões semanais por Discord",
	"saturday" => "Sábado às 19 horas UTC-4",
	"culture" => "Cultura",
	"article" => "Artigo",
	"proverb-1" => "Aprende-se um pouco com a vitória, aprende-se muito com um provérbio japonês de derrota",
	"proverb-2" => "Todos os homens podem ver estas tácticas pelas quais se conquista, mas o que ninguém pode ver é a estratégia a partir da qual a vitória se desenvolve. Sun Tzu.",



//News//
	"books" => "Alguns livros Shogi recomendados",
	"books-2" => "Existem numerosos livros de Shogi escritos e de grande qualidade. Podemos mencionar alguns: 'A Brief Introduction to Shogi' de Roger Hare,
Shogi Handicap Openings' da revista Shogi, 'Introduction to Handicap Play' de Larry Kaufman, 'Better Moves for Better Shogi' de
Aono Teruichi, 'A Arte de Shogi' por Tony Hosking",
	"strategy" => "Estratégi",
	"agost" => "Agosto",
	"deepmind" => "Google DeepMind e o Shogi",
	"deepmind-1" => "Incrível como o Google Deep Mind conseguiu criar uma inteligência artificial de tal forma que venceu Elmo, o antigo Campeão Mundial de Shogi.",
	"deepmind-2" => "AlphaZero é um programa de computador desenvolvido pela Google através de uma equipa multi-disciplinar.
Existem várias versões do AlphaZero mas uma das versões mais recentes permite-lhe aprender Shogi, Xadrez e Go
do zero, ou seja, apenas com as regras do jogo AlphaZero aprende a jogar, cria a sua própria teoria de jogo
e, ao contrário de outro software, não precisa de uma base de dados de abertura ou algo do género. Isto é permitido por um conjunto
de técnicas, algoritmos chamados Reinforcement Learnind, Convolutional Neural Networks, MonteCarlo algoritmo, etc.

AlphaZero no caso do Shogi e dos seus jogos contra o melhor programa do mundo, estava com uma maior percentagem de vitória. Ou seja, AlphaZero
consegue ter uma estratégia de jogo superior a qualquer outro programa anteriormente feito para o Shogi. O mesmo resultado foi obtido ao jogar Go e Xadrez
com os melhores programas respectivos em cada disciplina.

A Inteligência Artificial e todos estes avanços contribuem para o jogador que está em constante formação e progresso para aprender usando estes
como programas de apoio através de revisões dos jogos jogados.",
	"technology" => "Tecnologia",
	"shogi-opening" => "Aberturas no Shogi",
	"shogi-opening-2" => "Descubra algumas variações em várias aberturas no Shogi",
	"shogi-opening-3" => "As aparências são muito importantes no Shogi. No parquet da Torre Estatica, temos
o Peão Lateral, Yagura, Bispo Troca, Asa Dupla e no Ranging Rook que tem 
o Central, o Quarto, o Terceiro e o oposto. Para conhecer as variantes em cada uma destas aberturas
ajudará o jogador em formação a alcançar um nível mais elevado no seu jogo. Saber também
os vários castelos e a forma de os atacar é vital no Shogi. 

Um dos websites que tem material sobre este assunto é o website da Associação Shogi
da Bélgica.",
	"opening" => "Abertura",
	"shogi-and-go" => "Shogi e Go",
	"shogi-and-go-2" => "Há várias coisas em comum entre estes dois jogos de estratégia. uma é que em ambas as disciplinas é fundamental o sente, tem também estudos em termos de aberturas, finais. Além disso, podemos dizer que os jogadores são classificados entre níveis de força utilizando o sistema kyu-Dan utilizado também para as Artes Marciais. Os jogadores mais fortes são treinados com muita disciplina, estudo e alto nível de concentração quando estão num jogo. Quanto aos programas de computador no Shogi, temos Elmo, Hefeweizen, Ponanza entre outros. Em Go temos: KataGo, Leela entre outros programas. Sem dúvida, estas Ciências do Desporto desenvolvem em cada um dos praticantes uma nova forma de ver o mundo e desenvolver competências tais como concentração, memória, resolução de problemas, disciplina, respeito pelo adversário e integração cultural.",
	"animes" => "Animes",
	"art-ia" => "Alguns dos avanços feitos pela Inteligência Artificial",
	"art-ia-1" => "Como influenciou o desenvolvimento da Inteligência Artificial em Shogi, Go-Baduk, Xadrez no campo da Inteligência Artificial?
Depois de Deepl Blue ter batido em Kaparov no final dos anos 90,
os programas de xadrez apoiados muito substancialmente e continuam a apoiar a formação do aejdrecista dos melhores do mundo, Grandmaster Magnus Carlsen 
bem como os jogadores do clube. A mesma coisa acontece em Go, onde as inteligências artísticas que foram sofisticadas de 2016 até aqui
Com os avanços tecnológicos do DeepMind, os programas em Go tornaram-se muito fortes, de tal forma que os jogadores profissionais Go
conseguem vencer as máquinas mas com pelo menos duas peças de desvantagem. Programas Go como Leela, KataGo tornaram-se muito úteis e hoje ajudam milhares de jogadores 
no mundo para melhorar cada vez mais a sua técnica na disciplina. No Shogi, os programas ajudam igualmente a melhorar o nível de jogo nesta Ciência do Desporto. A
Através de revisões do jogo, os programas ajudam a alcançar a jogada mais eficaz numa determinada posição. Podem também dar um equilíbrio no jogo para que 
informe-nos sobre quem pode ter vantagem sobre o outro jogador num determinado momento do jogo.",
	"instagram" => "Instagram feed ",



///Ours FSA///
	"main-title-ours" => "Federação Americana de Shogi",
	"mision-fsa" => "A Federação Shogi Americana tem como missão a integração dos jogadores Shogi e das suas respectivas Associações Nacionais.",
	"fsa-members" => "Tem actualmente representantes de:",
	"argentina" => "Argentina",
	"brasil" => "Brasil",
	"canada" => "Canadá",
	"chile" => "Chile",
	"colombia" => "Colombia",
	"cuba" => "Cuba",
	"usa" => "Estados Unidos de América",
	"guatemala" => "Guatemala",
	"honduras" => "Honduras",
	"mexico" => "México",
	"peru" => "Perú",
	"republica-dominicana" => "República Dominicana",
	"venezuela" => "Venezuela",
	"culture-japanese" => "Mais sobre a cultura japonesa e Shogi",
	"proverb-about" => "Aprende-se um pouco com a vitória, aprende-se muito com uma derrota",
	"japanese-proverb" => "provérbio japonês",
	
	




);


//class="form-control" id="sel1"
