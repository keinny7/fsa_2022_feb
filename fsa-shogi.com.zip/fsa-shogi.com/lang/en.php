<?php

$lang = array(
	
	"menu_home" => "Home",
	"menu_news" => "News",
	"menu_ranking" => "Ranking",
	"menu_gallery" => "Gallery",
	"menu_tournaments" => "Tournaments",
	"menu_ours" => "About Us",
	"menu_links" => "Links",
	"menu_languaje" => "Language",
	"menu_contact" => "Contact",
	"menu_send" => "Send",

	"main-title-1" => "American Shogi",
	"main-title-2" => "Federation",

	//Tournament//
	"Tournament" => "Tournament",
	"T-months" => "Take part in our monthly Shogi Tournament!",
	"join-discord" => "Join us in Discord",
	"T-july" => "July Tournament",
	"Format" => "Format",
	"t-july-2" => "FSA July Tournament 2020",
	"direct-removal" => "Direct removal",
	"Period" => "Period",
	"Status" => "Satuts",
	"Click-see" => "Click to see at 81dojo.com",

	"japan" => "Japan",
	"japanese-culture" => "More about japanese culture and Shogi",
	"meetings" => "Weekly meetings by Discord",
	"saturday" => "Saturday to 19 hours UTC-4",
	"culture" => "Culture",
	"article" => "Article",
	"proverb-1" => "You learn a little from victory, you learn a lot from a defeat Japanese proverb",
	"proverb-2" => "All men can see these tactics by which one conquers, but what no one can see is the strategy from which victory develops. Sun Tzu.",
	

//News//
	"books" => "Some recommended Shogi books",
	"books-2" => "There are numerous books of Shogi written and of great quality. We can mention some: 'A Brief Introduction to Shogi' by Roger Hare,
Shogi Handicap Openings' by Shogi magazine, 'Introduction to Handicap Play' by Larry Kaufman, 'Better Moves for Better Shogi' by
Aono Teruichi, 'The Art of Shogi' by Tony Hosking",
	"strategy" => "Strategies",
	"agost" => "Agosto",
	"deepmind" => "Google DeepMind and Shogi",
	"deepmind-1" => "Amazing how Google Deep Mind managed to create an artificial intelligence in such a way that it will beat Elmo, the former Shogi World Champion.",
	"deepmind-2" => "AlphaZero is a computer program developed by Google through a multi-disciplinary team.
There are several versions of AlphaZero but one of the most recent versions allows you to learn Shogi, Chess and Go
from scratch, that is, only with the rules of the game AlphaZero learns to play, creates its own game theory
and in contrast to other software it doesn't need an opening database or anything like that. This is allowed by a set
of techniques, algorithms called Reinforcement Learnind, Convolutional Neural Networks, MonteCarlo algorithm etc.

AlphaZero in the case of Shogi and its games against the best program in the world, was with a higher percentage of victory. That is, AlphaZero
manages to have a game strategy superior to any other program previously made for the Shogi. The same result was obtained by playing Go and Chess
with the best respective programs in each discipline.

The Artificial Intelligence and all these advances contribute to the player who is in constant formation and progress to learn using these
as programs as support through reviews of games played.",
	"technology" => "Technology",
	"shogi-opening" => "Openings at the Shogi",
	"shogi-opening-2" => "Discover some variations in various openings in the Shogi",
	"shogi-opening-3" => "Appearances are very important in the Shogi. On the parquet of Torre Estatica, we have
the Side Pawn, Yagura, Bishop Exchange, Double Wing and in the Ranging Rook you have 
the Central, Fourth, Third and opposite. To know the variants in each of these openings
will help the player in formation to achieve a higher level in his game. Also knowing
the various castles and how to attack them is vital in the Shogi. 

One of the websites that has material on this subject is the website of the Shogi Association
from Belgium.",
	"opening" => "Opening",
	"shogi-and-go" => "Shogi and Go",
	"shogi-and-go-2" => "There are several things in common between these two games of strategy. one is that in both disciplines is fundamental the sente, also has studies in terms of openings, endings. Apart from this we can say that the players are classified between levels of strength using the kyu-Dan system used also for Martial Arts. The strongest players are trained with a lot of discipline, study and high level of concentration when they are in a game. As for the computer programs in Shogi we have Elmo, Hefeweizen, Ponanza among others. In Go we have: KataGo, Leela among other programs. Undoubtedly, these Sports-Sciences develop in each of the practitioners a new way of seeing the world and develop skills such as concentration, memory, problem solving, discipline, respect for the opponent and cultural integration.",
	"animes" => "Animes",
	"art-ia" => "Some advances made by Artificial Intelligence",
	"art-ia-1" => "How have you influenced the development of Artificial Intelligence in Shogi, Go-Baduk, Chess in the field of Artificial Intelligence?
After Deepl Blue beat Kaparov in the late 1990s,
the chess programs supported very substantially and continue to support the training of the aejdrecist from the best in the world, Grandmaster Magnus Carlsen 
as well as club players. The same thing happens in Go, where the artistic intelligences that were sophisticated from 2016 to here
With the technological advances of DeepMind, the programs in Go have become very strong, so much so that professional Go players
they manage to beat the machines but with at least two pieces of handicap. Go programs like Leela, KataGo have become very useful and today helps thousands of players 
in the world to increasingly improve their technique in the discipline. In Shogi similarly the programs help to improve the level of play in this Sport Science. A
Through game reviews, the programs help to achieve the most effective move in a given position. They can also give a balance in the game so that 
let us know who may have an advantage over the other player at a given time in the game.",
	"instagram" => "Instagram feed ",


///Ours FSA///
	"main-title-ours" => "American Shogi Federation",
	"mision-fsa" => "The American Shogi Federation has as its mission the integration of Shogi players and their respective National Associations.",
	"fsa-members" => "It currently has representatives from:",
	"argentina" => "Argentina",
	"brasil" => "Brazil",
	"canada" => "Canadá",
	"chile" => "Chile",
	"colombia" => "Colombia",
	"cuba" => "Cuba",
	"usa" => "United States of America",
	"guatemala" => "Guatemala",
	"honduras" => "Honduras",
	"mexico" => "México",
	"peru" => "Perú",
	"republica-dominicana" => "Dominican Republic",
	"venezuela" => "Venezuela",
	"culture-japanese" => "More on Japanese culture and the Shogi",
	"proverb-about" => "You learn a little from victory, you learn a lot from a defeat",
	"japanese-proverb" => "Japanese proverb",


);


//class="form-control" id="sel1"
