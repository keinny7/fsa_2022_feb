<?php 
    session_start();
    include "php/core/lang.php";
?>



<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>FSA </title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="manifest" href="site.webmanifest">
		<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

		<!-- CSS here -->
            <link rel="stylesheet" href="assets/css/bootstrap.min.css">
            <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
            <link rel="stylesheet" href="assets/css/slicknav.css">
            <link rel="stylesheet" href="assets/css/animate.min.css">
            <link rel="stylesheet" href="assets/css/magnific-popup.css">
            <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
            <link rel="stylesheet" href="assets/css/themify-icons.css">
            <link rel="stylesheet" href="assets/css/slick.css">
            <link rel="stylesheet" href="assets/css/nice-select.css">
            <link rel="stylesheet" href="assets/css/style.css">
            <link rel="stylesheet" href="assets/css/ranking_styles.css">
            <link type="text/css" rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/css/flag-icon.min.css"">
   </head> 

   <body class="body-bg">
    <!-- Preloader Start -->
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                    <img src="assets/img/logo/logo.png" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Preloader Start -->
    <header>
        <!-- Header Start -->
       <div class="header-area header-sticky">
            <div class="header-wrapper d-flex flex-wrap align-items-center justify-content-between">
                <!-- Logo -->
                <div class="logo">

                    <a href="?vista=main"><img src="assets/img/logo/logo.png" alt=""></a>
                </div>
                <div id="google_translate_element"></div>
                <!-- Main-menu -->
                <div class="main-menu d-none d-lg-block">
                    <nav>
                        <ul id="navigation">                                                     
                        <!-- Inicio
                            Noticas
                            Tsumes
                            Asociaciones y clubes
                            Galeria
                            Torneos
                            Elaces de Interés
                            Nosotros

                            <li><a href="blog.html">Noticias</a>
                                <ul class="submenu">
                                    <li><a href="blog.html">Blog</a></li>
                                    .... <li><a href="single-blog.html">Blog Details</a></li>
                                </ul>
                            </li>
                         -->                                                                          
                            <li><a href="?vista=main"><?php echo $lang["menu_home"] ?></a></li> <li><a href="?vista=noticias"><?php echo $lang["menu_news"] ?></a> <ul class="submenu"> 
                                <li><a href="?vista=n_proverbio">Proverbios y desarrollo humano</a></li>
<li><a href="?vista=n_fsa_team">FSA Torneo por equipos</a></li>
<li><a href="?vista=n_team">Torneo por equipos FSA pronto </a></li>
<li><a href="?vista=n_fsa_team_ronda_1">Torneo por equipos FSA, ronda 1</a></li>

 <li><a href="?vista=n_microcosmo">Microcosmo</a></li>
                            <li><a href="?vista=n_t_kyoto">Modalidad Kyoto</a></li>
                            <li><a href="?vista=n_t_kyoto_r">Torneo Kyoto FSA resultados</a></li>
                            <li><a href="?vista=n_perspectiva">Perspectiva</a></li>
                            <li><a href="?vista=n_gorogoro">Torneo Gorogoro</a></li>
                            
                            
                             </ul> </li> <!--<li><a href="?vista=Tsumes">Tsumes</a>
                            </li>-->

                            <li><a href="?vista=Ranking"><?php echo $lang["menu_ranking"] ?></a>                             
                            </li>
                            
                            <li><a href="?vista=gallery"><?php echo $lang["menu_gallery"] ?></a></li>
                            
                            <li><a href="?vista=Torneos"><?php echo $lang["menu_tournaments"] ?></a>
                                
                            </li>
                            
                            <li><a href="?vista=about">FSA</a></li>
                            <li><a href="?vista=Enlaces"><?php echo $lang["menu_links"] ?></a></li>
                            <li><a href="?vista=registro">Registro</a></li>
                            
                        
                            <!-- <li>
                            <form method="POST">
                
            
                <select class="custom-select" name="lang" style="display: ">                    
                    <option value="en">English</option>
                    <option value="es">Español</option>
                    <option value="pt">Portugés</option>
                    <option value="jpn">Japonés</option>
                </select>

                <button type="submit" class="btn"><?php echo $lang[" menu_send"] ?></button>

            </form>
                        </li> -->

                            <!-- <li><a href="?vista=Ranking">Ranking</a>                             
                            </li>
                            
                            <li><a href="?vista=gellary">Galeria</a></li>
                            
                            <li><a href="?vista=Torneos">Torneos</a>
                                
                            </li>
                            
                            <li><a href="?vista=about">Nosotros</a></li>
                            <li><a href="?vista=Enlaces">Enlaces de Interés</a></li> -->
                        </ul>
                    </nav>
                </div>          
                <!-- Header-btn -->
                <div class="d-none d-xl-block">
                    <a href="?vista=contact" class="btn btn2">Contáctanos</a>
                </div>
            
                <!-- Mobile Menu -->
                <div class="col-12">
                    <div class="mobile_menu d-block d-lg-none"></div>

                </div>
            
            </div>
       </div>
        <!-- Header End -->




    </header>
    <main>

    <?php
        require_once "php/core/router.php";
        $router = new Router();

        if(isset($_GET["vista"]))
        {
            $router->returnView($_GET["vista"]);
        }else{
            $router->returnView("main");
        }

    ?>

    </main>
   <footer>
        <div class="footer-area fix">
            <!-- Footer Caption -->
            <div class="footer-caption wow fadeInRight" data-wow-delay=".6s">
                <div class="footer-tittle">

                    <h3><?php echo $lang["main-title-1"] ?> <br> <?php echo $lang["main-title-2"] ?></h3>

                    <!-- <h3>Federación De Shogi <br> Americana</h3> -->

                </div>
                <div class="footer-menu ">
                    <div class="single-menu">
                        <div class="single-menu1">
                            <div class="single-footer-caption mb-50">
                                <div class="footer-tittle">
                                    <h4><?php echo $lang["menu_contact"] ?></h4>
                                    <div class="footer-pera">
                                        <p>federacion.shogi.america@gmail.com </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="single-menu2">
                            <div class="single-footer-caption mb-50">
                                <div class="footer-tittle">
                                    <h4><?php echo $lang["menu_links"] ?></h4>
                                    <ul>

                                        <li><a href="?vista=main"><?php echo $lang["menu_home"] ?></a></li>
                                        <!-- <li><a href="#">Torneos</a></li> -->
                                        <li><a href="?vista=about">FSA</a></li>
                                        <li><a href="?vista=contact"><?php echo $lang["menu_contact"] ?></a></li>

                                        <!-- <li><a href="?vista=main">Inicio</a></li> -->
                                        <!-- <li><a href="#">Torneos</a></li> -->
                                        <!-- <li><a href="?vista=about">About FSA</a></li> -->
                                        <!-- <li><a href="?vista=contact">Contáctanos</a></li> -->

                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="single-menu3">
                            <div class="single-footer-caption">
                                <div class="footer-tittle">
                                    <h4>Social</h4>
                                    <!-- Social -->
                                    <div class="footer-social">
                                        <a href="https://www.facebook.com/Federaci%C3%B3n-de-Shogi-Americana-107893957550442/" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                        <a href="https://www.instagram.com/federacion_shogi_americana/" target="_blank"><i class="fab fa-instagram"></i></a>
                                        <a href="https://www.youtube.com/channel/UCSQNXORKJ8vcaSPEAMOGugQ/videos" target="_blank"><i class="fab fa-youtube"></i></a>
                                        <a href="https://discord.gg/awS3Kt9" target="_blank"><i class="fab fa-discord"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="copyright pt-40">
                    <p><p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p></p>
                </div>
            </div>
        </div>
   </footer>
   
	<!-- JS here -->
	
		<!-- All JS Custom Plugins Link Here here -->
        <script src="./assets/js/vendor/modernizr-3.5.0.min.js"></script>
		
		<!-- Jquery, Popper, Bootstrap -->
		<script src="./assets/js/vendor/jquery-1.12.4.min.js"></script>
        <script src="./assets/js/popper.min.js"></script>
        <script src="./assets/js/bootstrap.min.js"></script>
	    <!-- Jquery Mobile Menu -->
        <script src="./assets/js/jquery.slicknav.min.js"></script>

		<!-- Jquery Slick , Owl-Carousel Plugins -->
        <script src="./assets/js/owl.carousel.min.js"></script>
        <script src="./assets/js/slick.min.js"></script>
		<!-- One Page, Animated-HeadLin -->
        <script src="./assets/js/wow.min.js"></script>
		<script src="./assets/js/animated.headline.js"></script>
        <script src="./assets/js/jquery.magnific-popup.js"></script>

		<!-- Scrollup, nice-select, sticky -->
        <script src="./assets/js/jquery.scrollUp.min.js"></script>
        <script src="./assets/js/jquery.nice-select.min.js"></script>
		<script src="./assets/js/jquery.sticky.js"></script>
        
        <!-- contact js -->
        <script src="./assets/js/contact.js"></script>
        <script src="./assets/js/jquery.form.js"></script>
        <script src="./assets/js/jquery.validate.min.js"></script>
        <script src="./assets/js/mail-script.js"></script>
        <script src="./assets/js/jquery.ajaxchimp.min.js"></script>
        
		<!-- Jquery Plugins, main Jquery -->	
        <script src="./assets/js/plugins.js"></script>
        <script src="./assets/js/main.js"></script>
        <script type="text/javascript"> $(document).ready(function(){$('#frmajax').submit(insertar) function insertar(evento){event.preventDefault() var datos= new FormData($("#frmajax")[0]); $.ajax({type:"POST", url:"p_insertar_bd_2.php", data:datos, contentType: false, processData: false, success:function(datos){$("#respuesta").html(datos) } }) } }); </script>


        <!-- traduccion scripts google -->

        <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'es'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
        
    </body>
</html>