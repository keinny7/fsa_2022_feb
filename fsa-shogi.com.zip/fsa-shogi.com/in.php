<?php $nombre=$_POST['nombre']; $pais=$_POST['pais']; $correo=$_POST['correo']; $comentario=$_POST['comentario']; $dojo=$_POST['dojo'];$selectrank=$_POST['selectrank'];$selectcom=$_POST['selectcom']; $mensaje = " Nombre: " . $nombre . "," . " Rank: " . $selectrank . "," . " Comision: " . $selectcom . "," . " Pais: " . $pais . "," . " Correo: " . $correo . "," . " Comentario: " . $comentario . "," . " Cuenta: " . $dojo; $mensaje = wordwrap($mensaje, 600, "\r\n"); mail('fsasecretary30@gmail.com', 'Registro', $mensaje); if($nombre) {echo "<script>location.href = 'https://www.fsa-shogi.com';</script>"; echo "<h3 style='color:blue;'> Se ha enviado la solicitud </h3>"; } else {echo "<h3 style='color:red;'> Ha ocurrido un error al enviar su solicitud </h3>"; } ?>







	  